# Treasure Hunt Game Notebook

## Read and Review Your Starter Code
The theme of this project is a popular treasure hunt game in which the player needs to find the treasure before the pirate does. While you will not be developing the entire game, you will write the part of the game that represents the intelligent agent, which is a pirate in this case. The pirate will try to find the optimal path to the treasure using deep Q-learning. 

<div class="alert alert-block alert-success" style="color:black;">
<b>To Begin:</b> Use this <b>TreasureHuntGame_starterCode.ipynb</b> file to complete your assignment. 
<br><br>
You have been provided with two Python classes and this notebook to help you with this assignment. The first class, <b>TreasureMaze.py</b>, represents the environment, which includes a maze object defined as a matrix. The second class, <b>GameExperience.py</b>, stores the episodes – that is, all the states that come in between the initial state and the terminal state. This is later used by the agent for learning by experience, called "exploration". This notebook shows how to play a game. Your task is to complete the deep Q-learning implementation in the qtrain() function for which a skeleton implementation has been provided. 
</div>
<br>
<div class="alert alert-block alert-info" style="color:black;">
<b>NOTE: </b>The code block you will need to complete will have <b>#TODO</b> as a header.
<br> First, read and review the next few code and instruction blocks to understand the code that you have been given.</div>

<div class="alert alert-block alert-warning" style="color: #333333;">
<b>Installations</b> The following command will install the necessary Python libraries to necessary to run this application. If you see a "[notice] A new release of pip is available: 23.1.2 -> 25.2" at the end of the installation, you may disregard that statement. 
</div>


```python
!pip install -r requirements.txt
```

    Requirement already satisfied: numpy==1.26.4 in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from -r requirements.txt (line 1)) (1.26.4)
    Requirement already satisfied: keras in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from -r requirements.txt (line 2)) (3.4.1)
    Requirement already satisfied: absl-py in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from keras->-r requirements.txt (line 2)) (2.1.0)
    Requirement already satisfied: rich in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from keras->-r requirements.txt (line 2)) (13.7.1)
    Requirement already satisfied: namex in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from keras->-r requirements.txt (line 2)) (0.0.8)
    Requirement already satisfied: h5py in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from keras->-r requirements.txt (line 2)) (3.11.0)
    Requirement already satisfied: optree in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from keras->-r requirements.txt (line 2)) (0.12.1)
    Requirement already satisfied: ml-dtypes in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from keras->-r requirements.txt (line 2)) (0.4.0)
    Requirement already satisfied: packaging in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from keras->-r requirements.txt (line 2)) (24.1)
    Requirement already satisfied: typing-extensions>=4.5.0 in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from optree->keras->-r requirements.txt (line 2)) (4.12.2)
    Requirement already satisfied: markdown-it-py>=2.2.0 in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from rich->keras->-r requirements.txt (line 2)) (3.0.0)
    Requirement already satisfied: pygments<3.0.0,>=2.13.0 in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from rich->keras->-r requirements.txt (line 2)) (2.18.0)
    Requirement already satisfied: mdurl~=0.1 in /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages (from markdown-it-py>=2.2.0->rich->keras->-r requirements.txt (line 2)) (0.1.2)
    
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m A new release of pip is available: [0m[31;49m24.1.2[0m[39;49m -> [0m[32;49m26.0.1[0m
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m To update, run: [0m[32;49mpip install --upgrade pip[0m


<h2>Tensorflow CPU Acceleration Warning</h2>
<div class="alert alert-block alert-danger" style="color: #333333;">
<b>GPU/CUDA/Memory Warnings/Errors:</b> You may receive some errors referencing that GPUs will not be used, CUDA could not be found, or free system memory allocation errors. These and a few others, are standard errors that can be ignored here as they are environment based.<br><br>
    <b>Example messages:</b>
    <ul>
        <li>oneDNN custom operations are on. You may see slightly different numerical results due to floating-point round-off errors from different computation orders</li>
        <li>WARNING: All log messages before absl::InitializeLog() is called are written to STDERR</li>
</div>


```python
#had to insert this to avoid CUDA errors preventing the model from training
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

from __future__ import print_function
import os, sys, time, datetime, json, random
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import clone_model
from keras.models import Sequential
from keras.layers import Dense, Activation, PReLU
from keras.optimizers import SGD , Adam, RMSprop
import matplotlib.pyplot as plt
from TreasureMaze import TreasureMaze
from GameExperience import GameExperience
%matplotlib inline
```

<h2> Maze Object Generation</h2>

<div class="alert alert-block alert-info" style="color:black;">
    <b>NOTE:</b>  The following code block contains an 8x8 matrix that will be used as a maze object:
</div>


```python
maze = np.array([
    [ 1.,  0.,  1.,  1.,  1.,  1.,  1.,  1.],
    [ 1.,  0.,  1.,  1.,  1.,  0.,  1.,  1.],
    [ 1.,  1.,  1.,  1.,  0.,  1.,  0.,  1.],
    [ 1.,  1.,  1.,  0.,  1.,  1.,  1.,  1.],
    [ 1.,  1.,  0.,  1.,  1.,  1.,  1.,  1.],
    [ 1.,  1.,  1.,  0.,  1.,  0.,  0.,  0.],
    [ 1.,  1.,  1.,  0.,  1.,  1.,  1.,  1.],
    [ 1.,  1.,  1.,  1.,  0.,  1.,  1.,  1.]
])
```

<h2>Helper Functions and Global Variables</h2>

<div class="alert alert-block alert-info" style="color:black;">
This <b>show()</b> helper function allows a visual representation of the maze object:
</div>


```python
def show(qmaze):
    plt.grid('on')
    nrows, ncols = qmaze.maze.shape
    ax = plt.gca()
    ax.set_xticks(np.arange(0.5, nrows, 1))
    ax.set_yticks(np.arange(0.5, ncols, 1))
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    canvas = np.copy(qmaze.maze)
    for row,col in qmaze.visited:
        canvas[row,col] = 0.6
    pirate_row, pirate_col, _ = qmaze.state
    canvas[pirate_row, pirate_col] = 0.3   # pirate cell
    canvas[nrows-1, ncols-1] = 0.9 # treasure cell
    img = plt.imshow(canvas, interpolation='none', cmap='gray')
    return img
```

The <b>pirate agent</b> can move in four directions: left, right, up, and down. 

<div class="alert alert-block alert-warning" style="color:black;">
<b>Note:</b> While the agent primarily learns by experience through exploitation, often, the agent can choose to explore the environment to find previously undiscovered paths. This is called "exploration" and is defined by epsilon. This value is the <b>EXPLORATION</b> values from the Cartpole assignment. The hyperparameters are provided here and used in the <b>qtrain()</b> method. 
You are encouraged to try various values for the exploration factor and see how the algorithm performs.
</div>


```python
LEFT = 0
UP = 1
RIGHT = 2
DOWN = 3


# Exploration factor
epsilon = 1.0
epsilon_min = 0.05
epsilon_decay = 0.995
patience = 10

# Actions dictionary
actions_dict = {
    LEFT: 'left',
    UP: 'up',
    RIGHT: 'right',
    DOWN: 'down',
}

num_actions = len(actions_dict)

```

The sample code block and output below show creating a maze object and performing one action (DOWN), which returns the reward. The resulting updated environment is visualized.


```python
qmaze = TreasureMaze(maze)
canvas, reward, game_over = qmaze.act(DOWN)
print("reward=", reward)
show(qmaze)
```

    reward= -0.04





    <matplotlib.image.AxesImage at 0x7ae3cc0cb350>




    
![png](output_13_2.png)
    


<div class="alert alert-block alert-warning" style="color:black;">
    <b>NOTE:</b> This <b>play_game()</b> function simulates a full game based on the provided trained model. The other parameters include the TreasureMaze object, the starting position of the pirate and max amount of steps to make sure the code does not get stuck in a loop.
</div>


```python
def play_game(model, qmaze, pirate_cell, max_steps=None):
    qmaze.reset(pirate_cell)
    envstate = qmaze.observe()
    steps = 0
    if max_steps is None:
        max_steps = qmaze.maze.size * 4  # safety cutoff

    while steps < max_steps:
        state = np.asarray(envstate, dtype=np.float32)
        if state.ndim == 1:
            state = np.expand_dims(state, axis=0)

        q_values = model(state, training=False).numpy()
        action = np.argmax(q_values[0])

        envstate, reward, game_status = qmaze.act(action)
        steps += 1

        if game_status == 'win':
            return True
        elif game_status == 'lose':
            return False

    return False  # timed out with no result
```

<div class="alert alert-block alert-warning" style="color:black;">
<b>Note: </b>
    This <b>completion_check()</b> function helps you to determine whether the pirate can win any game at all. If your maze is not well designed, the pirate may not win any game at all. In this case, your training would not yield any result. The provided maze in this notebook ensures that there is a path to win and you can run this method to check.
</div>


```python
def completion_check(model, maze_or_qmaze, max_steps=None):
    # Accept either raw numpy maze or TreasureMaze instance
    if isinstance(maze_or_qmaze, TreasureMaze):
        qmaze = maze_or_qmaze
    else:
        qmaze = TreasureMaze(maze_or_qmaze)

    for cell in qmaze.free_cells:
        if not qmaze.valid_actions(cell):
            continue
        if not play_game(model, qmaze, cell, max_steps=max_steps):
            return False
    return True
```

<div class="alert alert-block alert-warning" style="color:black;">
<b>Note: </b>
</b>The <b>build_model()</b> function in the block below will build the neural network model. Review the code and note the number of layers, as well as the activation, optimizer, and loss functions that are used to train the model.
</div>


```python
def build_model(maze):
    model = Sequential()
    model.add(Dense(maze.size, input_shape=(maze.size,)))
    model.add(PReLU())
    model.add(Dense(maze.size))
    model.add(PReLU())
    model.add(Dense(num_actions))
    model.compile(optimizer='adam', loss='mse')
    return model
```

<div class="alert alert-block alert-warning" style="color:black;">
    <b>Note:</b>
    This <b>train_step()</b> helper function in the block below is used to help predict Q-values (quality values) in the current modelto see how good each action is in a given state and improve the Q-network by reducing the gap between what is predicted and what should have been predicted. 
</div>
<br>
<div class="alert alert-block alert-info" style="color:black;">
If you're interested in reading up on the <i>@tf.function</i>, which is a decorator for Tensorflow to run this code into a TensorFlow computation graph, please refer to this link: <a href="https://www.tensorflow.org/guide/intro_to_graphs">https://www.tensorflow.org/guide/intro_to_graphs</a>
</div>


<h2>Tensorflow GPU Warning</h2>
<div class="alert alert-block alert-danger" style="color: #333333;">
    You will see a <b>warning in red</b> "INTERNAL: CUDA Runtime error: Failed call to cudaGetRuntimeVersion: Error loading CUDA libraries. GPU will not be used.". This is simply coming from <b>Tensorflow skipping using GPU for this assignment.</b>  
</div>


```python
loss_fn = tf.keras.losses.MeanSquaredError()
optimizer = tf.keras.optimizers.Adam()

@tf.function
def train_step(x, y):
    with tf.GradientTape() as tape:
        q_values = model(x, training=True)
        loss = loss_fn(y, q_values)
    grads = tape.gradient(loss, model.trainable_variables)
    optimizer.apply_gradients(zip(grads, model.trainable_variables))
    return loss
```

# #TODO: Complete the Q-Training Algorithm Code Block

<div class="alert alert-block alert-info" style="color:black;">
    This is your deep Q-learning implementation. The goal of your deep Q-learning implementation is to find the best possible navigation sequence that results in reaching the treasure cell while maximizing the reward. In your implementation, you need to determine the optimal number of epochs to achieve a 100% win rate.
</div>
    <b>Pseudocode:</b>
    <br>
    For each epoch:
        Reset the environment at a random starting cell
        agent_cell = randomly select a free cell
        <br>
        <b>Hint:</b> Review the reset method in the TreasureMaze.py class.
    
        Set the initial environment state
        env_state should reference the environment's current state
        Hint: Review the observe method in the TreasureMaze.py class.

        While game status is not game over:
           previous_envstate = env_state
            Decide on an action:
                - If possible, take a random valid exploration action and 
                  randomly choose action (left, right, up, down)
                  and assign it to an action variable
                - Else, pick the best exploitation action from the model and assign it to an action variable
                  Hint: Review the predict method in the GameExperience.py class.
    
           Retrieve the values below from the act() method.
           env_state, reward, game_status = qmaze.act(action)
           Hint: Review the act method in the TreasureMaze.py class.
    
            Track the wins and losses from the game_status using win_history 
         
           Store the episode below in the Experience replay object
           episode = [previous_envstate, action, reward, envstate, game_status]
           Hint: Review the remember method in the GameExperience.py class.
        
           Train neural network model and evaluate loss
           Hint: Call GameExperience.get_data to retrieve training data (input and target) 
           and pass to the train_step method and assign it to batch_loss and append to the loss variable
        
      If the win rate is above the threshold and your model passes the completion check, that would be your epoch.

Note: A 100% win rate <b>DOES NOT EXPLICITLY MEAN</b> that you have solved the maze. It simply indicates that during the last evaluation, the pirate <i>happened</i> to get to the treasure. Be sure to utilise the <b>completion_check()</b> function to validate your pirate found the treasure at every starting point and consistently! 

<b> You will need to complete the section starting with #START_HERE. Please use the pseudocode above as guidance. </b>



```python
def qtrain(model, maze, **opt):
    """
    Trains the pirate agent using Deep Q-Learning.
    Uses experience replay + target network for stable learning.
    """
    global epsilon

    # Hyperparameters
    n_epoch = opt.get('n_epoch', 15000)
    max_memory = opt.get('max_memory', 1000)
    data_size = opt.get('data_size', 50)
    target_update_freq = opt.get('target_update_freq', 50)

    start_time = datetime.datetime.now()

    # Create environment and target network
    qmaze = TreasureMaze(maze)
    target_model = clone_model(model)
    target_model.set_weights(model.get_weights())

    # Experience replay buffer
    experience = GameExperience(model, target_model, max_memory=max_memory)

    win_history = []      # track wins/losses for win rate calculation
    hsize = qmaze.maze.size // 2
    win_rate = 0.0

    print("Starting training...\n")

    # ====================== TRAINING LOOP ======================
    for epoch in range(n_epoch):
        # 1. Start new episode at random free cell
        pirate_cell = random.choice(qmaze.free_cells)
        qmaze.reset(pirate_cell)
        envstate = qmaze.observe()

        loss = 0.0
        n_episodes = 0
        game_over = False

        # 2. Play one full episode
        while not game_over:
            previous_envstate = envstate

            valid_actions = qmaze.valid_actions()
            if not valid_actions:
                break

            # 3. Epsilon-greedy action selection
            if np.random.rand() < epsilon:          # Exploration
                action = random.choice(valid_actions)
            else:                                   # Exploitation
                action = np.argmax(experience.predict(previous_envstate))

            # 4. Take action and get result
            envstate, reward, game_status = qmaze.act(action)
            n_episodes += 1

            done = game_status != 'not_over'
            if game_status == 'win':
                win_history.append(1)
            elif game_status == 'lose':
                win_history.append(0)

            # Store experience
            episode = [previous_envstate, action, reward, envstate, done]
            experience.remember(episode)

            # 5. Train on replay memory
            if len(experience.memory) >= data_size:
                inputs, targets = experience.get_data(data_size)
                loss_value = train_step(
                    tf.convert_to_tensor(inputs, dtype=tf.float32),
                    tf.convert_to_tensor(targets, dtype=tf.float32)
                )
                loss = loss_value.numpy()

            if done:
                game_over = True

        # 6. Update metrics and exploration rate
        if len(win_history) > hsize:
            win_rate = sum(win_history[-hsize:]) / hsize

        epsilon = max(epsilon * epsilon_decay, epsilon_min)

        # Update target network periodically
        if epoch % target_update_freq == 0:
            target_model.set_weights(model.get_weights())

        # Print progress
        dt = datetime.datetime.now() - start_time
        t = format_time(dt.total_seconds())
        print(f"Epoch: {epoch:03d}/{n_epoch-1} | Loss: {loss:.4f} | "
              f"Episodes: {n_episodes} | Win count: {sum(win_history)} | "
              f"Win rate: {win_rate:.3f} | time: {t}")

        # Early stopping when agent wins from every starting position
        if win_rate >= 0.999 and completion_check(model, qmaze):
            print(f"✅ Reached 100% win rate at epoch {epoch}")
            break

    # ====================== SAVE MODEL ======================
    name = opt.get('name', 'model')
    h5file = name + ".weights.h5"      # Required in Keras 3 to avoid missing directory error
    json_file = name + ".json"

    model.save_weights(h5file, overwrite=True)
    with open(json_file, "w") as outfile:
        json.dump(model.to_json(), outfile)

    total_time = format_time((datetime.datetime.now() - start_time).total_seconds())
    print("\n🎉 Training complete in:", total_time)
    print(f"Saved: {h5file} and {json_file}")
    print(f"Final epoch: {epoch}, max_mem: {max_memory}, data: {data_size}")

    return total_time

# Helper function to print readable time (seconds → minutes → hours)
def format_time(seconds):
    if seconds < 400:
        return f"{seconds:.1f} seconds"
    elif seconds < 4000:
        return f"{seconds/60:.2f} minutes"
    else:
        return f"{seconds/3600:.2f} hours"
```

## Test Your Model

Now we will start testing the deep Q-learning implementation. To begin, select **Cell**, then **Run All** from the menu bar. This will run your notebook. As it runs, you should see output begin to appear beneath the next few cells. The code below creates an <b>instance</b> of TreasureMaze. This does not show your actual training done.


```python
qmaze = TreasureMaze(maze)
show(qmaze)
```




    <matplotlib.image.AxesImage at 0x7ae32bcff350>




    
![png](output_26_1.png)
    


In the next code block, you will build your model using the <b>build_model</b> function and train it using deep Q-learning. Note: This step takes several minutes to fully run.



<div class="alert alert-block alert-danger" style="color: #333333;">
  <b>WARNING</b>  If you did not attempt the assignment, the code <b>will</b> error out at this section.
 </div>


```python
model = build_model(maze)
print ("made model\n")
qtrain(model, maze, n_epoch=1000, max_memory=8*maze.size, data_size=32, target_update_freq=50)
print("finnished qtrain\n")
```

    /home/codio/.pyenv/versions/3.11.9/lib/python3.11/site-packages/keras/src/layers/core/dense.py:87: UserWarning: Do not pass an `input_shape`/`input_dim` argument to a layer. When using Sequential models, prefer using an `Input(shape)` object as the first layer in the model instead.
      super().__init__(activity_regularizer=activity_regularizer, **kwargs)


    made model
    
    Starting training...
    
    Epoch: 000/999 | Loss: 0.0008 | Episodes: 138 | Win count: 0 | Win rate: 0.000 | time: 2.3 seconds
    Epoch: 001/999 | Loss: 0.0005 | Episodes: 144 | Win count: 0 | Win rate: 0.000 | time: 4.0 seconds
    Epoch: 002/999 | Loss: 0.0011 | Episodes: 150 | Win count: 0 | Win rate: 0.000 | time: 5.8 seconds
    Epoch: 003/999 | Loss: 0.0014 | Episodes: 164 | Win count: 0 | Win rate: 0.000 | time: 7.7 seconds
    Epoch: 004/999 | Loss: 0.0022 | Episodes: 136 | Win count: 1 | Win rate: 0.000 | time: 9.3 seconds
    Epoch: 005/999 | Loss: 0.0022 | Episodes: 150 | Win count: 1 | Win rate: 0.000 | time: 11.1 seconds
    Epoch: 006/999 | Loss: 0.0016 | Episodes: 3 | Win count: 2 | Win rate: 0.000 | time: 11.1 seconds
    Epoch: 007/999 | Loss: 0.0010 | Episodes: 139 | Win count: 2 | Win rate: 0.000 | time: 12.7 seconds
    Epoch: 008/999 | Loss: 0.0012 | Episodes: 150 | Win count: 2 | Win rate: 0.000 | time: 14.4 seconds
    Epoch: 009/999 | Loss: 0.0016 | Episodes: 157 | Win count: 2 | Win rate: 0.000 | time: 16.3 seconds
    Epoch: 010/999 | Loss: 0.0024 | Episodes: 31 | Win count: 3 | Win rate: 0.000 | time: 16.7 seconds
    Epoch: 011/999 | Loss: 0.0017 | Episodes: 15 | Win count: 4 | Win rate: 0.000 | time: 16.9 seconds
    Epoch: 012/999 | Loss: 0.0022 | Episodes: 144 | Win count: 4 | Win rate: 0.000 | time: 18.5 seconds
    Epoch: 013/999 | Loss: 0.0037 | Episodes: 141 | Win count: 4 | Win rate: 0.000 | time: 20.1 seconds
    Epoch: 014/999 | Loss: 0.0015 | Episodes: 157 | Win count: 4 | Win rate: 0.000 | time: 21.8 seconds
    Epoch: 015/999 | Loss: 0.0014 | Episodes: 143 | Win count: 4 | Win rate: 0.000 | time: 23.5 seconds
    Epoch: 016/999 | Loss: 0.0011 | Episodes: 145 | Win count: 4 | Win rate: 0.000 | time: 25.2 seconds
    Epoch: 017/999 | Loss: 0.0015 | Episodes: 144 | Win count: 4 | Win rate: 0.000 | time: 26.8 seconds
    Epoch: 018/999 | Loss: 0.0004 | Episodes: 150 | Win count: 4 | Win rate: 0.000 | time: 28.6 seconds
    Epoch: 019/999 | Loss: 0.0012 | Episodes: 163 | Win count: 5 | Win rate: 0.000 | time: 30.5 seconds
    Epoch: 020/999 | Loss: 0.0018 | Episodes: 144 | Win count: 5 | Win rate: 0.000 | time: 32.1 seconds
    Epoch: 021/999 | Loss: 0.0030 | Episodes: 30 | Win count: 6 | Win rate: 0.000 | time: 32.5 seconds
    Epoch: 022/999 | Loss: 0.0016 | Episodes: 125 | Win count: 7 | Win rate: 0.000 | time: 33.9 seconds
    Epoch: 023/999 | Loss: 0.0135 | Episodes: 145 | Win count: 7 | Win rate: 0.000 | time: 35.6 seconds
    Epoch: 024/999 | Loss: 0.0008 | Episodes: 139 | Win count: 7 | Win rate: 0.000 | time: 37.2 seconds
    Epoch: 025/999 | Loss: 0.0110 | Episodes: 155 | Win count: 7 | Win rate: 0.000 | time: 39.0 seconds
    Epoch: 026/999 | Loss: 0.0027 | Episodes: 158 | Win count: 7 | Win rate: 0.000 | time: 40.9 seconds
    Epoch: 027/999 | Loss: 0.0014 | Episodes: 147 | Win count: 7 | Win rate: 0.000 | time: 42.6 seconds
    Epoch: 028/999 | Loss: 0.0022 | Episodes: 26 | Win count: 8 | Win rate: 0.000 | time: 42.9 seconds
    Epoch: 029/999 | Loss: 0.0022 | Episodes: 132 | Win count: 9 | Win rate: 0.000 | time: 44.4 seconds
    Epoch: 030/999 | Loss: 0.0025 | Episodes: 139 | Win count: 9 | Win rate: 0.000 | time: 46.0 seconds
    Epoch: 031/999 | Loss: 0.0009 | Episodes: 66 | Win count: 10 | Win rate: 0.000 | time: 46.8 seconds
    Epoch: 032/999 | Loss: 0.0093 | Episodes: 140 | Win count: 10 | Win rate: 0.312 | time: 48.4 seconds
    Epoch: 033/999 | Loss: 0.0019 | Episodes: 2 | Win count: 11 | Win rate: 0.344 | time: 48.4 seconds
    Epoch: 034/999 | Loss: 0.0055 | Episodes: 6 | Win count: 12 | Win rate: 0.375 | time: 48.5 seconds
    Epoch: 035/999 | Loss: 0.0010 | Episodes: 146 | Win count: 12 | Win rate: 0.375 | time: 50.2 seconds
    Epoch: 036/999 | Loss: 0.0014 | Episodes: 1 | Win count: 13 | Win rate: 0.375 | time: 50.2 seconds
    Epoch: 037/999 | Loss: 0.0023 | Episodes: 143 | Win count: 13 | Win rate: 0.375 | time: 51.9 seconds
    Epoch: 038/999 | Loss: 0.0009 | Episodes: 149 | Win count: 13 | Win rate: 0.344 | time: 53.7 seconds
    Epoch: 039/999 | Loss: 0.0013 | Episodes: 147 | Win count: 13 | Win rate: 0.344 | time: 55.4 seconds
    Epoch: 040/999 | Loss: 0.0021 | Episodes: 144 | Win count: 13 | Win rate: 0.344 | time: 57.1 seconds
    Epoch: 041/999 | Loss: 0.0010 | Episodes: 147 | Win count: 13 | Win rate: 0.344 | time: 58.8 seconds
    Epoch: 042/999 | Loss: 0.0013 | Episodes: 58 | Win count: 14 | Win rate: 0.344 | time: 59.5 seconds
    Epoch: 043/999 | Loss: 0.0146 | Episodes: 3 | Win count: 15 | Win rate: 0.344 | time: 59.6 seconds
    Epoch: 044/999 | Loss: 0.0011 | Episodes: 149 | Win count: 15 | Win rate: 0.344 | time: 61.3 seconds
    Epoch: 045/999 | Loss: 0.0014 | Episodes: 148 | Win count: 15 | Win rate: 0.344 | time: 63.2 seconds
    Epoch: 046/999 | Loss: 0.0012 | Episodes: 150 | Win count: 15 | Win rate: 0.344 | time: 65.0 seconds
    Epoch: 047/999 | Loss: 0.0028 | Episodes: 143 | Win count: 15 | Win rate: 0.344 | time: 66.8 seconds
    Epoch: 048/999 | Loss: 0.0015 | Episodes: 3 | Win count: 16 | Win rate: 0.375 | time: 66.8 seconds
    Epoch: 049/999 | Loss: 0.0027 | Episodes: 151 | Win count: 16 | Win rate: 0.375 | time: 68.7 seconds
    Epoch: 050/999 | Loss: 0.0016 | Episodes: 151 | Win count: 16 | Win rate: 0.375 | time: 70.5 seconds
    Epoch: 051/999 | Loss: 0.0197 | Episodes: 52 | Win count: 17 | Win rate: 0.375 | time: 71.2 seconds
    Epoch: 052/999 | Loss: 0.0013 | Episodes: 140 | Win count: 17 | Win rate: 0.375 | time: 72.9 seconds
    Epoch: 053/999 | Loss: 0.0375 | Episodes: 111 | Win count: 18 | Win rate: 0.375 | time: 74.2 seconds
    Epoch: 054/999 | Loss: 0.0024 | Episodes: 158 | Win count: 18 | Win rate: 0.344 | time: 76.0 seconds
    Epoch: 055/999 | Loss: 0.0012 | Episodes: 150 | Win count: 18 | Win rate: 0.344 | time: 77.8 seconds
    Epoch: 056/999 | Loss: 0.0038 | Episodes: 149 | Win count: 18 | Win rate: 0.344 | time: 79.6 seconds
    Epoch: 057/999 | Loss: 0.0017 | Episodes: 141 | Win count: 18 | Win rate: 0.344 | time: 81.3 seconds
    Epoch: 058/999 | Loss: 0.0032 | Episodes: 153 | Win count: 18 | Win rate: 0.344 | time: 83.1 seconds
    Epoch: 059/999 | Loss: 0.0167 | Episodes: 150 | Win count: 18 | Win rate: 0.344 | time: 85.0 seconds
    Epoch: 060/999 | Loss: 0.0020 | Episodes: 111 | Win count: 19 | Win rate: 0.344 | time: 86.4 seconds
    Epoch: 061/999 | Loss: 0.0146 | Episodes: 6 | Win count: 20 | Win rate: 0.344 | time: 86.5 seconds
    Epoch: 062/999 | Loss: 0.0040 | Episodes: 42 | Win count: 21 | Win rate: 0.375 | time: 87.0 seconds
    Epoch: 063/999 | Loss: 0.0141 | Episodes: 144 | Win count: 21 | Win rate: 0.344 | time: 88.7 seconds
    Epoch: 064/999 | Loss: 0.0020 | Episodes: 42 | Win count: 22 | Win rate: 0.375 | time: 89.2 seconds
    Epoch: 065/999 | Loss: 0.0056 | Episodes: 9 | Win count: 23 | Win rate: 0.375 | time: 89.3 seconds
    Epoch: 066/999 | Loss: 0.0047 | Episodes: 142 | Win count: 23 | Win rate: 0.344 | time: 91.1 seconds
    Epoch: 067/999 | Loss: 0.0051 | Episodes: 94 | Win count: 24 | Win rate: 0.375 | time: 92.2 seconds
    Epoch: 068/999 | Loss: 0.0009 | Episodes: 144 | Win count: 24 | Win rate: 0.344 | time: 93.9 seconds
    Epoch: 069/999 | Loss: 0.0008 | Episodes: 150 | Win count: 24 | Win rate: 0.344 | time: 95.7 seconds
    Epoch: 070/999 | Loss: 0.0019 | Episodes: 92 | Win count: 25 | Win rate: 0.375 | time: 96.8 seconds
    Epoch: 071/999 | Loss: 0.0015 | Episodes: 30 | Win count: 26 | Win rate: 0.406 | time: 97.1 seconds
    Epoch: 072/999 | Loss: 0.0018 | Episodes: 144 | Win count: 26 | Win rate: 0.406 | time: 99.0 seconds
    Epoch: 073/999 | Loss: 0.0016 | Episodes: 131 | Win count: 27 | Win rate: 0.438 | time: 100.7 seconds
    Epoch: 074/999 | Loss: 0.0019 | Episodes: 18 | Win count: 28 | Win rate: 0.438 | time: 100.9 seconds
    Epoch: 075/999 | Loss: 0.0020 | Episodes: 69 | Win count: 29 | Win rate: 0.438 | time: 101.8 seconds
    Epoch: 076/999 | Loss: 0.0016 | Episodes: 75 | Win count: 30 | Win rate: 0.469 | time: 102.7 seconds
    Epoch: 077/999 | Loss: 0.0031 | Episodes: 144 | Win count: 30 | Win rate: 0.469 | time: 104.5 seconds
    Epoch: 078/999 | Loss: 0.0019 | Episodes: 154 | Win count: 30 | Win rate: 0.469 | time: 106.4 seconds
    Epoch: 079/999 | Loss: 0.0021 | Episodes: 112 | Win count: 31 | Win rate: 0.500 | time: 107.9 seconds
    Epoch: 080/999 | Loss: 0.0026 | Episodes: 7 | Win count: 32 | Win rate: 0.500 | time: 108.0 seconds
    Epoch: 081/999 | Loss: 0.0015 | Episodes: 1 | Win count: 33 | Win rate: 0.531 | time: 108.0 seconds
    Epoch: 082/999 | Loss: 0.0020 | Episodes: 153 | Win count: 33 | Win rate: 0.531 | time: 110.0 seconds
    Epoch: 083/999 | Loss: 0.0018 | Episodes: 150 | Win count: 33 | Win rate: 0.500 | time: 112.2 seconds
    Epoch: 084/999 | Loss: 0.0025 | Episodes: 145 | Win count: 33 | Win rate: 0.500 | time: 114.3 seconds
    Epoch: 085/999 | Loss: 0.0014 | Episodes: 11 | Win count: 34 | Win rate: 0.500 | time: 114.5 seconds
    Epoch: 086/999 | Loss: 0.0019 | Episodes: 55 | Win count: 35 | Win rate: 0.531 | time: 115.3 seconds
    Epoch: 087/999 | Loss: 0.0017 | Episodes: 50 | Win count: 36 | Win rate: 0.562 | time: 116.0 seconds
    Epoch: 088/999 | Loss: 0.0014 | Episodes: 139 | Win count: 36 | Win rate: 0.562 | time: 117.8 seconds
    Epoch: 089/999 | Loss: 0.0021 | Episodes: 80 | Win count: 37 | Win rate: 0.594 | time: 118.8 seconds
    Epoch: 090/999 | Loss: 0.0009 | Episodes: 122 | Win count: 38 | Win rate: 0.625 | time: 120.3 seconds
    Epoch: 091/999 | Loss: 0.0050 | Episodes: 146 | Win count: 38 | Win rate: 0.625 | time: 122.3 seconds
    Epoch: 092/999 | Loss: 0.0025 | Episodes: 151 | Win count: 38 | Win rate: 0.594 | time: 124.2 seconds
    Epoch: 093/999 | Loss: 0.0008 | Episodes: 155 | Win count: 38 | Win rate: 0.562 | time: 126.2 seconds
    Epoch: 094/999 | Loss: 0.0026 | Episodes: 8 | Win count: 39 | Win rate: 0.562 | time: 126.3 seconds
    Epoch: 095/999 | Loss: 0.0024 | Episodes: 50 | Win count: 40 | Win rate: 0.594 | time: 126.9 seconds
    Epoch: 096/999 | Loss: 0.0028 | Episodes: 144 | Win count: 40 | Win rate: 0.562 | time: 128.8 seconds
    Epoch: 097/999 | Loss: 0.0018 | Episodes: 11 | Win count: 41 | Win rate: 0.562 | time: 128.9 seconds
    Epoch: 098/999 | Loss: 0.0012 | Episodes: 42 | Win count: 42 | Win rate: 0.594 | time: 129.5 seconds
    Epoch: 099/999 | Loss: 0.0016 | Episodes: 1 | Win count: 43 | Win rate: 0.594 | time: 129.5 seconds
    Epoch: 100/999 | Loss: 0.0039 | Episodes: 12 | Win count: 44 | Win rate: 0.625 | time: 129.7 seconds
    Epoch: 101/999 | Loss: 0.0114 | Episodes: 150 | Win count: 44 | Win rate: 0.625 | time: 131.7 seconds
    Epoch: 102/999 | Loss: 0.0015 | Episodes: 155 | Win count: 44 | Win rate: 0.594 | time: 133.8 seconds
    Epoch: 103/999 | Loss: 0.0059 | Episodes: 140 | Win count: 44 | Win rate: 0.562 | time: 135.6 seconds
    Epoch: 104/999 | Loss: 0.0015 | Episodes: 5 | Win count: 45 | Win rate: 0.594 | time: 135.7 seconds
    Epoch: 105/999 | Loss: 0.0027 | Episodes: 10 | Win count: 46 | Win rate: 0.594 | time: 135.8 seconds
    Epoch: 106/999 | Loss: 0.0032 | Episodes: 1 | Win count: 47 | Win rate: 0.594 | time: 135.8 seconds
    Epoch: 107/999 | Loss: 0.0021 | Episodes: 80 | Win count: 48 | Win rate: 0.594 | time: 136.9 seconds
    Epoch: 108/999 | Loss: 0.0015 | Episodes: 37 | Win count: 49 | Win rate: 0.594 | time: 137.3 seconds
    Epoch: 109/999 | Loss: 0.0012 | Episodes: 143 | Win count: 50 | Win rate: 0.625 | time: 139.2 seconds
    Epoch: 110/999 | Loss: 0.0031 | Episodes: 20 | Win count: 51 | Win rate: 0.656 | time: 139.5 seconds
    Epoch: 111/999 | Loss: 0.0011 | Episodes: 148 | Win count: 51 | Win rate: 0.625 | time: 141.4 seconds
    Epoch: 112/999 | Loss: 0.0025 | Episodes: 23 | Win count: 52 | Win rate: 0.625 | time: 141.7 seconds
    Epoch: 113/999 | Loss: 0.0017 | Episodes: 142 | Win count: 52 | Win rate: 0.594 | time: 143.6 seconds
    Epoch: 114/999 | Loss: 0.0039 | Episodes: 76 | Win count: 53 | Win rate: 0.625 | time: 144.6 seconds
    Epoch: 115/999 | Loss: 0.0023 | Episodes: 147 | Win count: 53 | Win rate: 0.625 | time: 146.5 seconds
    Epoch: 116/999 | Loss: 0.0014 | Episodes: 148 | Win count: 53 | Win rate: 0.625 | time: 148.5 seconds
    Epoch: 117/999 | Loss: 0.0023 | Episodes: 155 | Win count: 53 | Win rate: 0.594 | time: 150.6 seconds
    Epoch: 118/999 | Loss: 0.0061 | Episodes: 18 | Win count: 54 | Win rate: 0.594 | time: 150.8 seconds
    Epoch: 119/999 | Loss: 0.0014 | Episodes: 2 | Win count: 55 | Win rate: 0.594 | time: 150.8 seconds
    Epoch: 120/999 | Loss: 0.0019 | Episodes: 14 | Win count: 56 | Win rate: 0.625 | time: 151.0 seconds
    Epoch: 121/999 | Loss: 0.0025 | Episodes: 152 | Win count: 56 | Win rate: 0.594 | time: 153.0 seconds
    Epoch: 122/999 | Loss: 0.0026 | Episodes: 144 | Win count: 56 | Win rate: 0.562 | time: 154.9 seconds
    Epoch: 123/999 | Loss: 0.0024 | Episodes: 141 | Win count: 56 | Win rate: 0.562 | time: 156.8 seconds
    Epoch: 124/999 | Loss: 0.0004 | Episodes: 139 | Win count: 56 | Win rate: 0.562 | time: 158.6 seconds
    Epoch: 125/999 | Loss: 0.0012 | Episodes: 148 | Win count: 56 | Win rate: 0.562 | time: 160.5 seconds
    Epoch: 126/999 | Loss: 0.0020 | Episodes: 152 | Win count: 56 | Win rate: 0.531 | time: 162.6 seconds
    Epoch: 127/999 | Loss: 0.0012 | Episodes: 145 | Win count: 56 | Win rate: 0.500 | time: 164.6 seconds
    Epoch: 128/999 | Loss: 0.0015 | Episodes: 49 | Win count: 57 | Win rate: 0.531 | time: 165.3 seconds
    Epoch: 129/999 | Loss: 0.0026 | Episodes: 155 | Win count: 57 | Win rate: 0.500 | time: 167.4 seconds
    Epoch: 130/999 | Loss: 0.0029 | Episodes: 148 | Win count: 57 | Win rate: 0.469 | time: 169.6 seconds
    Epoch: 131/999 | Loss: 0.0027 | Episodes: 155 | Win count: 57 | Win rate: 0.438 | time: 171.8 seconds
    Epoch: 132/999 | Loss: 0.0029 | Episodes: 33 | Win count: 58 | Win rate: 0.438 | time: 172.2 seconds
    Epoch: 133/999 | Loss: 0.0004 | Episodes: 145 | Win count: 58 | Win rate: 0.438 | time: 174.4 seconds
    Epoch: 134/999 | Loss: 0.0025 | Episodes: 35 | Win count: 59 | Win rate: 0.469 | time: 174.8 seconds
    Epoch: 135/999 | Loss: 0.0012 | Episodes: 151 | Win count: 59 | Win rate: 0.469 | time: 177.2 seconds
    Epoch: 136/999 | Loss: 0.0017 | Episodes: 149 | Win count: 59 | Win rate: 0.438 | time: 179.4 seconds
    Epoch: 137/999 | Loss: 0.0016 | Episodes: 7 | Win count: 60 | Win rate: 0.438 | time: 179.5 seconds
    Epoch: 138/999 | Loss: 0.0019 | Episodes: 107 | Win count: 61 | Win rate: 0.438 | time: 181.1 seconds
    Epoch: 139/999 | Loss: 0.0044 | Episodes: 45 | Win count: 62 | Win rate: 0.438 | time: 181.8 seconds
    Epoch: 140/999 | Loss: 0.0015 | Episodes: 62 | Win count: 63 | Win rate: 0.438 | time: 182.7 seconds
    Epoch: 141/999 | Loss: 0.0026 | Episodes: 70 | Win count: 64 | Win rate: 0.438 | time: 183.8 seconds
    Epoch: 142/999 | Loss: 0.0046 | Episodes: 152 | Win count: 64 | Win rate: 0.406 | time: 186.1 seconds
    Epoch: 143/999 | Loss: 0.0016 | Episodes: 144 | Win count: 64 | Win rate: 0.406 | time: 188.3 seconds
    Epoch: 144/999 | Loss: 0.0019 | Episodes: 57 | Win count: 65 | Win rate: 0.406 | time: 189.2 seconds
    Epoch: 145/999 | Loss: 0.0018 | Episodes: 143 | Win count: 65 | Win rate: 0.406 | time: 191.3 seconds
    Epoch: 146/999 | Loss: 0.0012 | Episodes: 25 | Win count: 66 | Win rate: 0.406 | time: 191.7 seconds
    Epoch: 147/999 | Loss: 0.0017 | Episodes: 141 | Win count: 66 | Win rate: 0.406 | time: 193.9 seconds
    Epoch: 148/999 | Loss: 0.0014 | Episodes: 15 | Win count: 67 | Win rate: 0.438 | time: 194.1 seconds
    Epoch: 149/999 | Loss: 0.0023 | Episodes: 33 | Win count: 68 | Win rate: 0.469 | time: 194.6 seconds
    Epoch: 150/999 | Loss: 0.0024 | Episodes: 144 | Win count: 68 | Win rate: 0.438 | time: 196.7 seconds
    Epoch: 151/999 | Loss: 0.0120 | Episodes: 143 | Win count: 68 | Win rate: 0.406 | time: 198.9 seconds
    Epoch: 152/999 | Loss: 0.0116 | Episodes: 33 | Win count: 69 | Win rate: 0.406 | time: 199.4 seconds
    Epoch: 153/999 | Loss: 0.0026 | Episodes: 161 | Win count: 69 | Win rate: 0.406 | time: 201.7 seconds
    Epoch: 154/999 | Loss: 0.0019 | Episodes: 106 | Win count: 70 | Win rate: 0.438 | time: 203.3 seconds
    Epoch: 155/999 | Loss: 0.0045 | Episodes: 150 | Win count: 70 | Win rate: 0.438 | time: 205.5 seconds
    Epoch: 156/999 | Loss: 0.0019 | Episodes: 140 | Win count: 71 | Win rate: 0.469 | time: 207.7 seconds
    Epoch: 157/999 | Loss: 0.0023 | Episodes: 105 | Win count: 72 | Win rate: 0.500 | time: 209.3 seconds
    Epoch: 158/999 | Loss: 0.0021 | Episodes: 30 | Win count: 73 | Win rate: 0.531 | time: 209.8 seconds
    Epoch: 159/999 | Loss: 0.0016 | Episodes: 140 | Win count: 73 | Win rate: 0.531 | time: 212.1 seconds
    Epoch: 160/999 | Loss: 0.0038 | Episodes: 24 | Win count: 74 | Win rate: 0.531 | time: 212.6 seconds
    Epoch: 161/999 | Loss: 0.0058 | Episodes: 27 | Win count: 75 | Win rate: 0.562 | time: 213.1 seconds
    Epoch: 162/999 | Loss: 0.0017 | Episodes: 2 | Win count: 76 | Win rate: 0.594 | time: 213.2 seconds
    Epoch: 163/999 | Loss: 0.0036 | Episodes: 17 | Win count: 77 | Win rate: 0.625 | time: 213.5 seconds
    Epoch: 164/999 | Loss: 0.0038 | Episodes: 14 | Win count: 78 | Win rate: 0.625 | time: 213.7 seconds
    Epoch: 165/999 | Loss: 0.0010 | Episodes: 161 | Win count: 78 | Win rate: 0.625 | time: 216.5 seconds
    Epoch: 166/999 | Loss: 0.0042 | Episodes: 143 | Win count: 78 | Win rate: 0.594 | time: 219.4 seconds
    Epoch: 167/999 | Loss: 0.0014 | Episodes: 16 | Win count: 79 | Win rate: 0.625 | time: 219.6 seconds
    Epoch: 168/999 | Loss: 0.0016 | Episodes: 144 | Win count: 79 | Win rate: 0.625 | time: 222.1 seconds
    Epoch: 169/999 | Loss: 0.0029 | Episodes: 20 | Win count: 80 | Win rate: 0.625 | time: 222.4 seconds
    Epoch: 170/999 | Loss: 0.0028 | Episodes: 117 | Win count: 81 | Win rate: 0.625 | time: 224.2 seconds
    Epoch: 171/999 | Loss: 0.0041 | Episodes: 45 | Win count: 82 | Win rate: 0.625 | time: 224.9 seconds
    Epoch: 172/999 | Loss: 0.0027 | Episodes: 34 | Win count: 83 | Win rate: 0.625 | time: 225.5 seconds
    Epoch: 173/999 | Loss: 0.0019 | Episodes: 2 | Win count: 84 | Win rate: 0.625 | time: 225.5 seconds
    Epoch: 174/999 | Loss: 0.0028 | Episodes: 2 | Win count: 85 | Win rate: 0.656 | time: 225.6 seconds
    Epoch: 175/999 | Loss: 0.0018 | Episodes: 31 | Win count: 86 | Win rate: 0.688 | time: 226.1 seconds
    Epoch: 176/999 | Loss: 0.0020 | Episodes: 41 | Win count: 87 | Win rate: 0.688 | time: 226.8 seconds
    Epoch: 177/999 | Loss: 0.0019 | Episodes: 150 | Win count: 87 | Win rate: 0.688 | time: 229.1 seconds
    Epoch: 178/999 | Loss: 0.0019 | Episodes: 144 | Win count: 87 | Win rate: 0.656 | time: 231.4 seconds
    Epoch: 179/999 | Loss: 0.0019 | Episodes: 21 | Win count: 88 | Win rate: 0.688 | time: 231.7 seconds
    Epoch: 180/999 | Loss: 0.0014 | Episodes: 135 | Win count: 89 | Win rate: 0.688 | time: 234.1 seconds
    Epoch: 181/999 | Loss: 0.0019 | Episodes: 30 | Win count: 90 | Win rate: 0.688 | time: 234.6 seconds
    Epoch: 182/999 | Loss: 0.0016 | Episodes: 150 | Win count: 90 | Win rate: 0.688 | time: 237.1 seconds
    Epoch: 183/999 | Loss: 0.0008 | Episodes: 75 | Win count: 91 | Win rate: 0.719 | time: 238.3 seconds
    Epoch: 184/999 | Loss: 0.0013 | Episodes: 61 | Win count: 92 | Win rate: 0.719 | time: 239.3 seconds
    Epoch: 185/999 | Loss: 0.0014 | Episodes: 14 | Win count: 93 | Win rate: 0.750 | time: 239.6 seconds
    Epoch: 186/999 | Loss: 0.0016 | Episodes: 9 | Win count: 94 | Win rate: 0.750 | time: 239.7 seconds
    Epoch: 187/999 | Loss: 0.0012 | Episodes: 131 | Win count: 95 | Win rate: 0.781 | time: 241.9 seconds
    Epoch: 188/999 | Loss: 0.0019 | Episodes: 31 | Win count: 96 | Win rate: 0.781 | time: 242.5 seconds
    Epoch: 189/999 | Loss: 0.0014 | Episodes: 9 | Win count: 97 | Win rate: 0.781 | time: 242.6 seconds
    Epoch: 190/999 | Loss: 0.0020 | Episodes: 42 | Win count: 98 | Win rate: 0.781 | time: 243.2 seconds
    Epoch: 191/999 | Loss: 0.0023 | Episodes: 94 | Win count: 99 | Win rate: 0.812 | time: 244.7 seconds
    Epoch: 192/999 | Loss: 0.0023 | Episodes: 41 | Win count: 100 | Win rate: 0.812 | time: 245.4 seconds
    Epoch: 193/999 | Loss: 0.0027 | Episodes: 46 | Win count: 101 | Win rate: 0.812 | time: 246.2 seconds
    Epoch: 194/999 | Loss: 0.0030 | Episodes: 11 | Win count: 102 | Win rate: 0.812 | time: 246.4 seconds
    Epoch: 195/999 | Loss: 0.0022 | Episodes: 47 | Win count: 103 | Win rate: 0.812 | time: 247.2 seconds
    Epoch: 196/999 | Loss: 0.0024 | Episodes: 27 | Win count: 104 | Win rate: 0.812 | time: 247.7 seconds
    Epoch: 197/999 | Loss: 0.0021 | Episodes: 40 | Win count: 105 | Win rate: 0.844 | time: 248.3 seconds
    Epoch: 198/999 | Loss: 0.0027 | Episodes: 147 | Win count: 106 | Win rate: 0.875 | time: 250.7 seconds
    Epoch: 199/999 | Loss: 0.0019 | Episodes: 2 | Win count: 107 | Win rate: 0.875 | time: 250.8 seconds
    Epoch: 200/999 | Loss: 0.0030 | Episodes: 5 | Win count: 108 | Win rate: 0.906 | time: 250.9 seconds
    Epoch: 201/999 | Loss: 0.0133 | Episodes: 22 | Win count: 109 | Win rate: 0.906 | time: 251.2 seconds
    Epoch: 202/999 | Loss: 0.0044 | Episodes: 138 | Win count: 109 | Win rate: 0.875 | time: 253.4 seconds
    Epoch: 203/999 | Loss: 0.0025 | Episodes: 42 | Win count: 110 | Win rate: 0.875 | time: 254.1 seconds
    Epoch: 204/999 | Loss: 0.0036 | Episodes: 69 | Win count: 111 | Win rate: 0.875 | time: 255.2 seconds
    Epoch: 205/999 | Loss: 0.0017 | Episodes: 71 | Win count: 112 | Win rate: 0.875 | time: 256.4 seconds
    Epoch: 206/999 | Loss: 0.0024 | Episodes: 44 | Win count: 113 | Win rate: 0.875 | time: 257.2 seconds
    Epoch: 207/999 | Loss: 0.0019 | Episodes: 19 | Win count: 114 | Win rate: 0.875 | time: 257.6 seconds
    Epoch: 208/999 | Loss: 0.0013 | Episodes: 7 | Win count: 115 | Win rate: 0.875 | time: 257.7 seconds
    Epoch: 209/999 | Loss: 0.0021 | Episodes: 19 | Win count: 116 | Win rate: 0.906 | time: 257.9 seconds
    Epoch: 210/999 | Loss: 0.0032 | Episodes: 42 | Win count: 117 | Win rate: 0.938 | time: 258.7 seconds
    Epoch: 211/999 | Loss: 0.0022 | Episodes: 63 | Win count: 118 | Win rate: 0.938 | time: 259.8 seconds
    Epoch: 212/999 | Loss: 0.0019 | Episodes: 59 | Win count: 119 | Win rate: 0.938 | time: 260.8 seconds
    Epoch: 213/999 | Loss: 0.0026 | Episodes: 55 | Win count: 120 | Win rate: 0.938 | time: 261.7 seconds
    Epoch: 214/999 | Loss: 0.0030 | Episodes: 1 | Win count: 121 | Win rate: 0.969 | time: 261.7 seconds
    Epoch: 215/999 | Loss: 0.0026 | Episodes: 145 | Win count: 122 | Win rate: 0.969 | time: 264.0 seconds
    Epoch: 216/999 | Loss: 0.0020 | Episodes: 62 | Win count: 123 | Win rate: 0.969 | time: 265.0 seconds
    Epoch: 217/999 | Loss: 0.0020 | Episodes: 80 | Win count: 124 | Win rate: 0.969 | time: 266.3 seconds
    Epoch: 218/999 | Loss: 0.0017 | Episodes: 4 | Win count: 125 | Win rate: 0.969 | time: 266.4 seconds
    Epoch: 219/999 | Loss: 0.0018 | Episodes: 8 | Win count: 126 | Win rate: 0.969 | time: 266.6 seconds
    Epoch: 220/999 | Loss: 0.0018 | Episodes: 34 | Win count: 127 | Win rate: 0.969 | time: 267.2 seconds
    Epoch: 221/999 | Loss: 0.0030 | Episodes: 7 | Win count: 128 | Win rate: 0.969 | time: 267.3 seconds
    Epoch: 222/999 | Loss: 0.0024 | Episodes: 15 | Win count: 129 | Win rate: 0.969 | time: 267.6 seconds
    Epoch: 223/999 | Loss: 0.0020 | Episodes: 124 | Win count: 130 | Win rate: 0.969 | time: 269.5 seconds
    Epoch: 224/999 | Loss: 0.0019 | Episodes: 10 | Win count: 131 | Win rate: 0.969 | time: 269.6 seconds
    Epoch: 225/999 | Loss: 0.0025 | Episodes: 70 | Win count: 132 | Win rate: 0.969 | time: 270.9 seconds
    Epoch: 226/999 | Loss: 0.0024 | Episodes: 6 | Win count: 133 | Win rate: 0.969 | time: 271.0 seconds
    Epoch: 227/999 | Loss: 0.0029 | Episodes: 1 | Win count: 134 | Win rate: 0.969 | time: 271.0 seconds
    Epoch: 228/999 | Loss: 0.0023 | Episodes: 33 | Win count: 135 | Win rate: 0.969 | time: 271.5 seconds
    Epoch: 229/999 | Loss: 0.0023 | Episodes: 41 | Win count: 136 | Win rate: 0.969 | time: 272.2 seconds
    Epoch: 230/999 | Loss: 0.0026 | Episodes: 44 | Win count: 137 | Win rate: 0.969 | time: 273.0 seconds
    Epoch: 231/999 | Loss: 0.0018 | Episodes: 57 | Win count: 138 | Win rate: 0.969 | time: 274.0 seconds
    Epoch: 232/999 | Loss: 0.0018 | Episodes: 83 | Win count: 139 | Win rate: 0.969 | time: 275.5 seconds
    Epoch: 233/999 | Loss: 0.0019 | Episodes: 28 | Win count: 140 | Win rate: 0.969 | time: 275.9 seconds
    Epoch: 234/999 | Loss: 0.0021 | Episodes: 27 | Win count: 141 | Win rate: 1.000 | time: 276.3 seconds
    Epoch: 235/999 | Loss: 0.0017 | Episodes: 12 | Win count: 142 | Win rate: 1.000 | time: 277.2 seconds
    Epoch: 236/999 | Loss: 0.0025 | Episodes: 94 | Win count: 143 | Win rate: 1.000 | time: 279.3 seconds
    Epoch: 237/999 | Loss: 0.0022 | Episodes: 24 | Win count: 144 | Win rate: 1.000 | time: 280.4 seconds
    Epoch: 238/999 | Loss: 0.0028 | Episodes: 145 | Win count: 144 | Win rate: 0.969 | time: 283.6 seconds
    Epoch: 239/999 | Loss: 0.0021 | Episodes: 41 | Win count: 145 | Win rate: 0.969 | time: 284.2 seconds
    Epoch: 240/999 | Loss: 0.0021 | Episodes: 10 | Win count: 146 | Win rate: 0.969 | time: 284.3 seconds
    Epoch: 241/999 | Loss: 0.0025 | Episodes: 74 | Win count: 147 | Win rate: 0.969 | time: 285.6 seconds
    Epoch: 242/999 | Loss: 0.0047 | Episodes: 60 | Win count: 148 | Win rate: 0.969 | time: 286.6 seconds
    Epoch: 243/999 | Loss: 0.0021 | Episodes: 53 | Win count: 149 | Win rate: 0.969 | time: 287.5 seconds
    Epoch: 244/999 | Loss: 0.0024 | Episodes: 53 | Win count: 150 | Win rate: 0.969 | time: 288.5 seconds
    Epoch: 245/999 | Loss: 0.0014 | Episodes: 40 | Win count: 151 | Win rate: 0.969 | time: 289.1 seconds
    Epoch: 246/999 | Loss: 0.0013 | Episodes: 29 | Win count: 152 | Win rate: 0.969 | time: 289.5 seconds
    Epoch: 247/999 | Loss: 0.0023 | Episodes: 10 | Win count: 153 | Win rate: 0.969 | time: 289.7 seconds
    Epoch: 248/999 | Loss: 0.0027 | Episodes: 40 | Win count: 154 | Win rate: 0.969 | time: 290.4 seconds
    Epoch: 249/999 | Loss: 0.0022 | Episodes: 15 | Win count: 155 | Win rate: 0.969 | time: 290.6 seconds
    Epoch: 250/999 | Loss: 0.0020 | Episodes: 34 | Win count: 156 | Win rate: 0.969 | time: 291.2 seconds
    Epoch: 251/999 | Loss: 0.0029 | Episodes: 149 | Win count: 156 | Win rate: 0.938 | time: 293.9 seconds
    Epoch: 252/999 | Loss: 0.0022 | Episodes: 119 | Win count: 157 | Win rate: 0.938 | time: 295.9 seconds
    Epoch: 253/999 | Loss: 0.0020 | Episodes: 70 | Win count: 158 | Win rate: 0.938 | time: 296.9 seconds
    Epoch: 254/999 | Loss: 0.0024 | Episodes: 23 | Win count: 159 | Win rate: 0.938 | time: 297.3 seconds
    Epoch: 255/999 | Loss: 0.0017 | Episodes: 147 | Win count: 160 | Win rate: 0.938 | time: 299.8 seconds
    Epoch: 256/999 | Loss: 0.0023 | Episodes: 36 | Win count: 161 | Win rate: 0.938 | time: 300.4 seconds
    Epoch: 257/999 | Loss: 0.0021 | Episodes: 8 | Win count: 162 | Win rate: 0.938 | time: 300.5 seconds
    Epoch: 258/999 | Loss: 0.0025 | Episodes: 27 | Win count: 163 | Win rate: 0.938 | time: 301.0 seconds
    Epoch: 259/999 | Loss: 0.0029 | Episodes: 1 | Win count: 164 | Win rate: 0.938 | time: 301.0 seconds
    Epoch: 260/999 | Loss: 0.0023 | Episodes: 4 | Win count: 165 | Win rate: 0.938 | time: 301.0 seconds
    Epoch: 261/999 | Loss: 0.0019 | Episodes: 64 | Win count: 166 | Win rate: 0.938 | time: 302.1 seconds
    Epoch: 262/999 | Loss: 0.0023 | Episodes: 51 | Win count: 167 | Win rate: 0.938 | time: 303.0 seconds
    Epoch: 263/999 | Loss: 0.0032 | Episodes: 17 | Win count: 168 | Win rate: 0.938 | time: 303.3 seconds
    Epoch: 264/999 | Loss: 0.0016 | Episodes: 2 | Win count: 169 | Win rate: 0.938 | time: 303.4 seconds
    Epoch: 265/999 | Loss: 0.0020 | Episodes: 53 | Win count: 170 | Win rate: 0.938 | time: 304.2 seconds
    Epoch: 266/999 | Loss: 0.0024 | Episodes: 15 | Win count: 171 | Win rate: 0.938 | time: 304.5 seconds
    Epoch: 267/999 | Loss: 0.0028 | Episodes: 18 | Win count: 172 | Win rate: 0.938 | time: 304.8 seconds
    Epoch: 268/999 | Loss: 0.0019 | Episodes: 20 | Win count: 173 | Win rate: 0.938 | time: 305.2 seconds
    Epoch: 269/999 | Loss: 0.0018 | Episodes: 8 | Win count: 174 | Win rate: 0.938 | time: 305.3 seconds
    Epoch: 270/999 | Loss: 0.0014 | Episodes: 66 | Win count: 175 | Win rate: 0.969 | time: 306.4 seconds
    Epoch: 271/999 | Loss: 0.0020 | Episodes: 23 | Win count: 176 | Win rate: 0.969 | time: 306.8 seconds
    Epoch: 272/999 | Loss: 0.0016 | Episodes: 14 | Win count: 177 | Win rate: 0.969 | time: 307.0 seconds
    Epoch: 273/999 | Loss: 0.0018 | Episodes: 22 | Win count: 178 | Win rate: 0.969 | time: 307.4 seconds
    Epoch: 274/999 | Loss: 0.0024 | Episodes: 10 | Win count: 179 | Win rate: 0.969 | time: 307.6 seconds
    Epoch: 275/999 | Loss: 0.0020 | Episodes: 27 | Win count: 180 | Win rate: 0.969 | time: 308.0 seconds
    Epoch: 276/999 | Loss: 0.0018 | Episodes: 79 | Win count: 181 | Win rate: 0.969 | time: 309.3 seconds
    Epoch: 277/999 | Loss: 0.0026 | Episodes: 4 | Win count: 182 | Win rate: 0.969 | time: 309.3 seconds
    Epoch: 278/999 | Loss: 0.0019 | Episodes: 31 | Win count: 183 | Win rate: 0.969 | time: 309.8 seconds
    Epoch: 279/999 | Loss: 0.0017 | Episodes: 6 | Win count: 184 | Win rate: 0.969 | time: 309.9 seconds
    Epoch: 280/999 | Loss: 0.0017 | Episodes: 9 | Win count: 185 | Win rate: 0.969 | time: 310.1 seconds
    Epoch: 281/999 | Loss: 0.0018 | Episodes: 17 | Win count: 186 | Win rate: 0.969 | time: 310.4 seconds
    Epoch: 282/999 | Loss: 0.0020 | Episodes: 15 | Win count: 187 | Win rate: 0.969 | time: 310.6 seconds
    Epoch: 283/999 | Loss: 0.0019 | Episodes: 7 | Win count: 188 | Win rate: 1.000 | time: 310.7 seconds
    Epoch: 284/999 | Loss: 0.0012 | Episodes: 27 | Win count: 189 | Win rate: 1.000 | time: 311.7 seconds
    Epoch: 285/999 | Loss: 0.0017 | Episodes: 9 | Win count: 190 | Win rate: 1.000 | time: 312.4 seconds
    Epoch: 286/999 | Loss: 0.0017 | Episodes: 20 | Win count: 191 | Win rate: 1.000 | time: 313.3 seconds
    Epoch: 287/999 | Loss: 0.0016 | Episodes: 33 | Win count: 192 | Win rate: 1.000 | time: 314.3 seconds
    Epoch: 288/999 | Loss: 0.0026 | Episodes: 38 | Win count: 193 | Win rate: 1.000 | time: 315.5 seconds
    Epoch: 289/999 | Loss: 0.0019 | Episodes: 1 | Win count: 194 | Win rate: 1.000 | time: 316.0 seconds
    Epoch: 290/999 | Loss: 0.0018 | Episodes: 21 | Win count: 195 | Win rate: 1.000 | time: 317.0 seconds
    Epoch: 291/999 | Loss: 0.0018 | Episodes: 21 | Win count: 196 | Win rate: 1.000 | time: 317.8 seconds
    Epoch: 292/999 | Loss: 0.0013 | Episodes: 19 | Win count: 197 | Win rate: 1.000 | time: 318.7 seconds
    Epoch: 293/999 | Loss: 0.0017 | Episodes: 1 | Win count: 198 | Win rate: 1.000 | time: 319.3 seconds
    Epoch: 294/999 | Loss: 0.0012 | Episodes: 24 | Win count: 199 | Win rate: 1.000 | time: 320.2 seconds
    Epoch: 295/999 | Loss: 0.0015 | Episodes: 23 | Win count: 200 | Win rate: 1.000 | time: 321.2 seconds
    Epoch: 296/999 | Loss: 0.0011 | Episodes: 48 | Win count: 201 | Win rate: 1.000 | time: 322.5 seconds
    Epoch: 297/999 | Loss: 0.0012 | Episodes: 7 | Win count: 202 | Win rate: 1.000 | time: 324.4 seconds
    Epoch: 298/999 | Loss: 0.0024 | Episodes: 31 | Win count: 203 | Win rate: 1.000 | time: 325.5 seconds
    Epoch: 299/999 | Loss: 0.0018 | Episodes: 39 | Win count: 204 | Win rate: 1.000 | time: 328.1 seconds
    Epoch: 300/999 | Loss: 0.0016 | Episodes: 30 | Win count: 205 | Win rate: 1.000 | time: 330.3 seconds
    Epoch: 301/999 | Loss: 0.0078 | Episodes: 140 | Win count: 205 | Win rate: 0.969 | time: 334.3 seconds
    Epoch: 302/999 | Loss: 0.0032 | Episodes: 96 | Win count: 206 | Win rate: 0.969 | time: 336.0 seconds
    Epoch: 303/999 | Loss: 0.0029 | Episodes: 47 | Win count: 207 | Win rate: 0.969 | time: 336.8 seconds
    Epoch: 304/999 | Loss: 0.0047 | Episodes: 2 | Win count: 208 | Win rate: 0.969 | time: 336.9 seconds
    Epoch: 305/999 | Loss: 0.0045 | Episodes: 47 | Win count: 209 | Win rate: 0.969 | time: 337.6 seconds
    Epoch: 306/999 | Loss: 0.0023 | Episodes: 13 | Win count: 210 | Win rate: 0.969 | time: 337.8 seconds
    Epoch: 307/999 | Loss: 0.0025 | Episodes: 11 | Win count: 211 | Win rate: 0.969 | time: 338.0 seconds
    Epoch: 308/999 | Loss: 0.0016 | Episodes: 86 | Win count: 212 | Win rate: 0.969 | time: 339.4 seconds
    Epoch: 309/999 | Loss: 0.0021 | Episodes: 1 | Win count: 213 | Win rate: 0.969 | time: 339.4 seconds
    Epoch: 310/999 | Loss: 0.0047 | Episodes: 24 | Win count: 214 | Win rate: 0.969 | time: 339.8 seconds
    Epoch: 311/999 | Loss: 0.0053 | Episodes: 14 | Win count: 215 | Win rate: 0.969 | time: 340.0 seconds
    Epoch: 312/999 | Loss: 0.0019 | Episodes: 49 | Win count: 216 | Win rate: 0.969 | time: 340.8 seconds
    Epoch: 313/999 | Loss: 0.0039 | Episodes: 22 | Win count: 217 | Win rate: 0.969 | time: 341.1 seconds
    Epoch: 314/999 | Loss: 0.0022 | Episodes: 5 | Win count: 218 | Win rate: 0.969 | time: 341.2 seconds
    Epoch: 315/999 | Loss: 0.0119 | Episodes: 89 | Win count: 219 | Win rate: 0.969 | time: 342.6 seconds
    Epoch: 316/999 | Loss: 0.0024 | Episodes: 3 | Win count: 220 | Win rate: 0.969 | time: 342.6 seconds
    Epoch: 317/999 | Loss: 0.0042 | Episodes: 7 | Win count: 221 | Win rate: 0.969 | time: 342.7 seconds
    Epoch: 318/999 | Loss: 0.0025 | Episodes: 5 | Win count: 222 | Win rate: 0.969 | time: 342.8 seconds
    Epoch: 319/999 | Loss: 0.0027 | Episodes: 24 | Win count: 223 | Win rate: 0.969 | time: 343.2 seconds
    Epoch: 320/999 | Loss: 0.0058 | Episodes: 21 | Win count: 224 | Win rate: 0.969 | time: 343.5 seconds
    Epoch: 321/999 | Loss: 0.0018 | Episodes: 58 | Win count: 225 | Win rate: 0.969 | time: 344.5 seconds
    Epoch: 322/999 | Loss: 0.0052 | Episodes: 4 | Win count: 226 | Win rate: 0.969 | time: 344.6 seconds
    Epoch: 323/999 | Loss: 0.0019 | Episodes: 5 | Win count: 227 | Win rate: 0.969 | time: 344.7 seconds
    Epoch: 324/999 | Loss: 0.0027 | Episodes: 30 | Win count: 228 | Win rate: 0.969 | time: 345.1 seconds
    Epoch: 325/999 | Loss: 0.0027 | Episodes: 18 | Win count: 229 | Win rate: 0.969 | time: 345.5 seconds
    Epoch: 326/999 | Loss: 0.0020 | Episodes: 45 | Win count: 230 | Win rate: 0.969 | time: 346.2 seconds
    Epoch: 327/999 | Loss: 0.0011 | Episodes: 13 | Win count: 231 | Win rate: 0.969 | time: 346.5 seconds
    Epoch: 328/999 | Loss: 0.0023 | Episodes: 33 | Win count: 232 | Win rate: 0.969 | time: 347.1 seconds
    Epoch: 329/999 | Loss: 0.0034 | Episodes: 15 | Win count: 233 | Win rate: 0.969 | time: 347.3 seconds
    Epoch: 330/999 | Loss: 0.0138 | Episodes: 10 | Win count: 234 | Win rate: 0.969 | time: 347.5 seconds
    Epoch: 331/999 | Loss: 0.0026 | Episodes: 17 | Win count: 235 | Win rate: 0.969 | time: 347.7 seconds
    Epoch: 332/999 | Loss: 0.0024 | Episodes: 23 | Win count: 236 | Win rate: 0.969 | time: 348.1 seconds
    Epoch: 333/999 | Loss: 0.0021 | Episodes: 1 | Win count: 237 | Win rate: 1.000 | time: 348.1 seconds
    Epoch: 334/999 | Loss: 0.0017 | Episodes: 14 | Win count: 238 | Win rate: 1.000 | time: 350.2 seconds
    Epoch: 335/999 | Loss: 0.0019 | Episodes: 7 | Win count: 239 | Win rate: 1.000 | time: 350.9 seconds
    Epoch: 336/999 | Loss: 0.0026 | Episodes: 32 | Win count: 240 | Win rate: 1.000 | time: 352.0 seconds
    Epoch: 337/999 | Loss: 0.0022 | Episodes: 9 | Win count: 241 | Win rate: 1.000 | time: 352.7 seconds
    Epoch: 338/999 | Loss: 0.0015 | Episodes: 3 | Win count: 242 | Win rate: 1.000 | time: 353.3 seconds
    Epoch: 339/999 | Loss: 0.0010 | Episodes: 6 | Win count: 243 | Win rate: 1.000 | time: 353.9 seconds
    Epoch: 340/999 | Loss: 0.0020 | Episodes: 31 | Win count: 244 | Win rate: 1.000 | time: 355.0 seconds
    Epoch: 341/999 | Loss: 0.0016 | Episodes: 29 | Win count: 245 | Win rate: 1.000 | time: 356.0 seconds
    Epoch: 342/999 | Loss: 0.0020 | Episodes: 10 | Win count: 246 | Win rate: 1.000 | time: 356.7 seconds
    Epoch: 343/999 | Loss: 0.0081 | Episodes: 54 | Win count: 247 | Win rate: 1.000 | time: 358.1 seconds
    Epoch: 344/999 | Loss: 0.0056 | Episodes: 2 | Win count: 248 | Win rate: 1.000 | time: 358.7 seconds
    Epoch: 345/999 | Loss: 0.0030 | Episodes: 24 | Win count: 249 | Win rate: 1.000 | time: 359.7 seconds
    Epoch: 346/999 | Loss: 0.0055 | Episodes: 66 | Win count: 250 | Win rate: 1.000 | time: 361.3 seconds
    Epoch: 347/999 | Loss: 0.0018 | Episodes: 12 | Win count: 251 | Win rate: 1.000 | time: 362.0 seconds
    Epoch: 348/999 | Loss: 0.0030 | Episodes: 26 | Win count: 252 | Win rate: 1.000 | time: 363.0 seconds
    Epoch: 349/999 | Loss: 0.0038 | Episodes: 39 | Win count: 253 | Win rate: 1.000 | time: 364.3 seconds
    Epoch: 350/999 | Loss: 0.0052 | Episodes: 1 | Win count: 254 | Win rate: 1.000 | time: 364.9 seconds
    Epoch: 351/999 | Loss: 0.0108 | Episodes: 144 | Win count: 255 | Win rate: 1.000 | time: 367.8 seconds
    Epoch: 352/999 | Loss: 0.0051 | Episodes: 77 | Win count: 256 | Win rate: 1.000 | time: 369.7 seconds
    Epoch: 353/999 | Loss: 0.0091 | Episodes: 43 | Win count: 257 | Win rate: 1.000 | time: 371.0 seconds
    Epoch: 354/999 | Loss: 0.0100 | Episodes: 14 | Win count: 258 | Win rate: 1.000 | time: 371.7 seconds
    Epoch: 355/999 | Loss: 0.0084 | Episodes: 26 | Win count: 259 | Win rate: 1.000 | time: 372.7 seconds
    Epoch: 356/999 | Loss: 0.0154 | Episodes: 19 | Win count: 260 | Win rate: 1.000 | time: 373.5 seconds
    Epoch: 357/999 | Loss: 0.0021 | Episodes: 84 | Win count: 261 | Win rate: 1.000 | time: 375.5 seconds
    Epoch: 358/999 | Loss: 0.0023 | Episodes: 54 | Win count: 262 | Win rate: 1.000 | time: 376.9 seconds
    Epoch: 359/999 | Loss: 0.0042 | Episodes: 11 | Win count: 263 | Win rate: 1.000 | time: 377.6 seconds
    Epoch: 360/999 | Loss: 0.0021 | Episodes: 47 | Win count: 264 | Win rate: 1.000 | time: 379.0 seconds
    Epoch: 361/999 | Loss: 0.0032 | Episodes: 44 | Win count: 265 | Win rate: 1.000 | time: 381.6 seconds
    Epoch: 362/999 | Loss: 0.0029 | Episodes: 10 | Win count: 266 | Win rate: 1.000 | time: 383.5 seconds
    Epoch: 363/999 | Loss: 0.0020 | Episodes: 68 | Win count: 267 | Win rate: 1.000 | time: 386.4 seconds
    Epoch: 364/999 | Loss: 0.0021 | Episodes: 32 | Win count: 268 | Win rate: 1.000 | time: 387.5 seconds
    Epoch: 365/999 | Loss: 0.0019 | Episodes: 60 | Win count: 269 | Win rate: 1.000 | time: 389.0 seconds
    Epoch: 366/999 | Loss: 0.0018 | Episodes: 120 | Win count: 270 | Win rate: 1.000 | time: 391.5 seconds
    Epoch: 367/999 | Loss: 0.0018 | Episodes: 32 | Win count: 271 | Win rate: 1.000 | time: 393.8 seconds
    Epoch: 368/999 | Loss: 0.0030 | Episodes: 20 | Win count: 272 | Win rate: 1.000 | time: 396.0 seconds
    Epoch: 369/999 | Loss: 0.0018 | Episodes: 40 | Win count: 273 | Win rate: 1.000 | time: 397.3 seconds
    Epoch: 370/999 | Loss: 0.0020 | Episodes: 17 | Win count: 274 | Win rate: 1.000 | time: 399.3 seconds
    Epoch: 371/999 | Loss: 0.0018 | Episodes: 21 | Win count: 275 | Win rate: 1.000 | time: 6.67 minutes
    Epoch: 372/999 | Loss: 0.0019 | Episodes: 42 | Win count: 276 | Win rate: 1.000 | time: 6.69 minutes
    Epoch: 373/999 | Loss: 0.0032 | Episodes: 22 | Win count: 277 | Win rate: 1.000 | time: 6.73 minutes
    Epoch: 374/999 | Loss: 0.0032 | Episodes: 11 | Win count: 278 | Win rate: 1.000 | time: 6.76 minutes
    Epoch: 375/999 | Loss: 0.0044 | Episodes: 33 | Win count: 279 | Win rate: 1.000 | time: 6.80 minutes
    Epoch: 376/999 | Loss: 0.0028 | Episodes: 5 | Win count: 280 | Win rate: 1.000 | time: 6.81 minutes
    Epoch: 377/999 | Loss: 0.0029 | Episodes: 7 | Win count: 281 | Win rate: 1.000 | time: 6.84 minutes
    Epoch: 378/999 | Loss: 0.0007 | Episodes: 35 | Win count: 282 | Win rate: 1.000 | time: 6.86 minutes
    Epoch: 379/999 | Loss: 0.0021 | Episodes: 53 | Win count: 283 | Win rate: 1.000 | time: 6.90 minutes
    Epoch: 380/999 | Loss: 0.0018 | Episodes: 29 | Win count: 284 | Win rate: 1.000 | time: 6.94 minutes
    Epoch: 381/999 | Loss: 0.0060 | Episodes: 18 | Win count: 285 | Win rate: 1.000 | time: 6.98 minutes
    Epoch: 382/999 | Loss: 0.0012 | Episodes: 34 | Win count: 286 | Win rate: 1.000 | time: 6.99 minutes
    Epoch: 383/999 | Loss: 0.0038 | Episodes: 9 | Win count: 287 | Win rate: 1.000 | time: 7.01 minutes
    Epoch: 384/999 | Loss: 0.0021 | Episodes: 42 | Win count: 288 | Win rate: 1.000 | time: 7.05 minutes
    Epoch: 385/999 | Loss: 0.0022 | Episodes: 3 | Win count: 289 | Win rate: 1.000 | time: 7.08 minutes
    Epoch: 386/999 | Loss: 0.0028 | Episodes: 46 | Win count: 290 | Win rate: 1.000 | time: 7.12 minutes
    Epoch: 387/999 | Loss: 0.0046 | Episodes: 11 | Win count: 291 | Win rate: 1.000 | time: 7.15 minutes
    Epoch: 388/999 | Loss: 0.0035 | Episodes: 32 | Win count: 292 | Win rate: 1.000 | time: 7.19 minutes
    Epoch: 389/999 | Loss: 0.0011 | Episodes: 29 | Win count: 293 | Win rate: 1.000 | time: 7.21 minutes
    Epoch: 390/999 | Loss: 0.0011 | Episodes: 17 | Win count: 294 | Win rate: 1.000 | time: 7.25 minutes
    Epoch: 391/999 | Loss: 0.0011 | Episodes: 8 | Win count: 295 | Win rate: 1.000 | time: 7.31 minutes
    Epoch: 392/999 | Loss: 0.0018 | Episodes: 23 | Win count: 296 | Win rate: 1.000 | time: 7.32 minutes
    Epoch: 393/999 | Loss: 0.0016 | Episodes: 31 | Win count: 297 | Win rate: 1.000 | time: 7.36 minutes
    Epoch: 394/999 | Loss: 0.0010 | Episodes: 24 | Win count: 298 | Win rate: 1.000 | time: 7.40 minutes
    Epoch: 395/999 | Loss: 0.0021 | Episodes: 7 | Win count: 299 | Win rate: 1.000 | time: 7.41 minutes
    Epoch: 396/999 | Loss: 0.0024 | Episodes: 31 | Win count: 300 | Win rate: 1.000 | time: 7.45 minutes
    Epoch: 397/999 | Loss: 0.0013 | Episodes: 29 | Win count: 301 | Win rate: 1.000 | time: 7.47 minutes
    Epoch: 398/999 | Loss: 0.0010 | Episodes: 4 | Win count: 302 | Win rate: 1.000 | time: 7.50 minutes
    Epoch: 399/999 | Loss: 0.0013 | Episodes: 8 | Win count: 303 | Win rate: 1.000 | time: 7.51 minutes
    Epoch: 400/999 | Loss: 0.0017 | Episodes: 44 | Win count: 304 | Win rate: 1.000 | time: 7.58 minutes
    Epoch: 401/999 | Loss: 0.0038 | Episodes: 7 | Win count: 305 | Win rate: 1.000 | time: 7.59 minutes
    Epoch: 402/999 | Loss: 0.0059 | Episodes: 112 | Win count: 306 | Win rate: 1.000 | time: 7.63 minutes
    Epoch: 403/999 | Loss: 0.0040 | Episodes: 31 | Win count: 307 | Win rate: 1.000 | time: 7.64 minutes
    Epoch: 404/999 | Loss: 0.0019 | Episodes: 79 | Win count: 308 | Win rate: 1.000 | time: 7.67 minutes
    Epoch: 405/999 | Loss: 0.0036 | Episodes: 1 | Win count: 309 | Win rate: 1.000 | time: 7.68 minutes
    Epoch: 406/999 | Loss: 0.0023 | Episodes: 5 | Win count: 310 | Win rate: 1.000 | time: 7.69 minutes
    Epoch: 407/999 | Loss: 0.0043 | Episodes: 34 | Win count: 311 | Win rate: 1.000 | time: 7.71 minutes
    Epoch: 408/999 | Loss: 0.0054 | Episodes: 31 | Win count: 312 | Win rate: 1.000 | time: 7.73 minutes
    Epoch: 409/999 | Loss: 0.0036 | Episodes: 13 | Win count: 313 | Win rate: 1.000 | time: 7.74 minutes
    Epoch: 410/999 | Loss: 0.0038 | Episodes: 29 | Win count: 314 | Win rate: 1.000 | time: 7.76 minutes
    Epoch: 411/999 | Loss: 0.0034 | Episodes: 62 | Win count: 315 | Win rate: 1.000 | time: 7.81 minutes
    Epoch: 412/999 | Loss: 0.0011 | Episodes: 40 | Win count: 316 | Win rate: 1.000 | time: 7.83 minutes
    Epoch: 413/999 | Loss: 0.0022 | Episodes: 51 | Win count: 317 | Win rate: 1.000 | time: 7.89 minutes
    Epoch: 414/999 | Loss: 0.0024 | Episodes: 27 | Win count: 318 | Win rate: 1.000 | time: 7.92 minutes
    Epoch: 415/999 | Loss: 0.0024 | Episodes: 24 | Win count: 319 | Win rate: 1.000 | time: 7.94 minutes
    Epoch: 416/999 | Loss: 0.0021 | Episodes: 47 | Win count: 320 | Win rate: 1.000 | time: 8.00 minutes
    Epoch: 417/999 | Loss: 0.0018 | Episodes: 29 | Win count: 321 | Win rate: 1.000 | time: 8.01 minutes
    Epoch: 418/999 | Loss: 0.0015 | Episodes: 17 | Win count: 322 | Win rate: 1.000 | time: 8.05 minutes
    Epoch: 419/999 | Loss: 0.0017 | Episodes: 20 | Win count: 323 | Win rate: 1.000 | time: 8.08 minutes
    Epoch: 420/999 | Loss: 0.0017 | Episodes: 26 | Win count: 324 | Win rate: 1.000 | time: 8.10 minutes
    Epoch: 421/999 | Loss: 0.0010 | Episodes: 30 | Win count: 325 | Win rate: 1.000 | time: 8.12 minutes
    Epoch: 422/999 | Loss: 0.0013 | Episodes: 24 | Win count: 326 | Win rate: 1.000 | time: 8.16 minutes
    Epoch: 423/999 | Loss: 0.0017 | Episodes: 23 | Win count: 327 | Win rate: 1.000 | time: 8.19 minutes
    Epoch: 424/999 | Loss: 0.0012 | Episodes: 6 | Win count: 328 | Win rate: 1.000 | time: 8.20 minutes
    Epoch: 425/999 | Loss: 0.0003 | Episodes: 18 | Win count: 329 | Win rate: 1.000 | time: 8.22 minutes
    Epoch: 426/999 | Loss: 0.0015 | Episodes: 19 | Win count: 330 | Win rate: 1.000 | time: 8.25 minutes
    Epoch: 427/999 | Loss: 0.0016 | Episodes: 32 | Win count: 331 | Win rate: 1.000 | time: 8.29 minutes
    Epoch: 428/999 | Loss: 0.0012 | Episodes: 13 | Win count: 332 | Win rate: 1.000 | time: 8.31 minutes
    Epoch: 429/999 | Loss: 0.0010 | Episodes: 37 | Win count: 333 | Win rate: 1.000 | time: 8.33 minutes
    Epoch: 430/999 | Loss: 0.0010 | Episodes: 18 | Win count: 334 | Win rate: 1.000 | time: 8.36 minutes
    Epoch: 431/999 | Loss: 0.0017 | Episodes: 21 | Win count: 335 | Win rate: 1.000 | time: 8.40 minutes
    Epoch: 432/999 | Loss: 0.0008 | Episodes: 31 | Win count: 336 | Win rate: 1.000 | time: 8.44 minutes
    Epoch: 433/999 | Loss: 0.0008 | Episodes: 8 | Win count: 337 | Win rate: 1.000 | time: 8.47 minutes
    Epoch: 434/999 | Loss: 0.0018 | Episodes: 24 | Win count: 338 | Win rate: 1.000 | time: 8.51 minutes
    Epoch: 435/999 | Loss: 0.0008 | Episodes: 8 | Win count: 339 | Win rate: 1.000 | time: 8.53 minutes
    Epoch: 436/999 | Loss: 0.0007 | Episodes: 10 | Win count: 340 | Win rate: 1.000 | time: 8.56 minutes
    ✅ Reached 100% win rate at epoch 436
    
    🎉 Training complete in: 8.61 minutes
    Saved: model.weights.h5 and model.json
    Final epoch: 436, max_mem: 512, data: 32
    finnished qtrain
    


<div class="alert alert-block alert-warning" style="color:black;">
<b>Note: </b> This cell will check to see if the model passes the completion check. Note: This could take several minutes.
</div>


```python
completion_check(model, qmaze)
show(qmaze)
```




    <matplotlib.image.AxesImage at 0x7ae32be33350>




    
![png](output_31_1.png)
    


This cell will test your model for one game. It will start the pirate at the top-left corner and run <b>play_game()</b>. The agent should find a path from the starting position to the target (treasure). The treasure is located in the bottom-right corner.


```python
pirate_start = (0, 0)
play_game(model, qmaze, pirate_start)
show(qmaze)
```




    <matplotlib.image.AxesImage at 0x7ae3cc0ce850>




    
![png](output_33_1.png)
    


## Save and Submit Your Work

<div class="alert alert-block alert-info" style="color:black;">
    <b>Hint:</b> To use the markdown block below, double click in the <b>Type Markdown and LaTeX:  𝛼2</b> block below, to turn it back to html, Run the cell.
</div>

After you have finished creating the code for your notebook, save your work.
Make sure that your notebook contains your name in the filename (e.g. Doe_Jane_ProjectTwo.html). Download this file as an .html file clicking on ***file*** in *Jupyter Notebook*, navigating down to ***Download as*** and clicking on ***.html***. 
Download a copy of your .html file and submit it to Brightspace.


```python

```
